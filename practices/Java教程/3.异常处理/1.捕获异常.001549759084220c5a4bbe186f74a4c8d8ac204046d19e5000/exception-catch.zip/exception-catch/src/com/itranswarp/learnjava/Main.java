package com.itranswarp.learnjava;

/**
 * Learn Java from https://www.liaoxuefeng.com/
 * 
 * @author liaoxuefeng
 */
public class Main {

	public static void main(String[] args) {
		process("20");
		process("0");
		process("abc");
	}

	static void process(String s) {
		System.out.println("process " + s + "...");
		try {
			int n = Integer.parseInt(s);
			int m = 100 / n;
			System.out.println("result: " + m);
		} catch (NumberFormatException e) {
			System.out.println("bad input: " + e);
		} catch (ArithmeticException e) {
			System.out.println("bad input: " + e);
		} finally {
			System.out.println("finally.");
		}
	}
}
