package com.itranswarp.learnjava;

public class StateCouncilSpecialAllowance implements Income {

	double income;

	public StateCouncilSpecialAllowance(double income) {
		this.income = income;
	}

	@Override
	public double getTax() {
		return 0;
	}

	@Override
	public double getTaxRate() {
		return 0;
	}
}
