package com.itranswarp.learnjava;

public interface Income {

	double getTax();

	default double getTaxRate() {
		return 0.2;
	}
}
