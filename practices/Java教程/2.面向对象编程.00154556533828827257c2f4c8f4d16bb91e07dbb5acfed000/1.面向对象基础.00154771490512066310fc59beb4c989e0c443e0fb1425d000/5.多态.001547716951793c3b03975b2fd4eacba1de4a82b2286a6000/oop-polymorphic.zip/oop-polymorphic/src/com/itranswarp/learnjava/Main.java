package com.itranswarp.learnjava;

/**
 * Learn Java from https://www.liaoxuefeng.com/
 * 
 * @author liaoxuefeng
 */
public class Main {

	public static void main(String[] args) {
		// 给一个享受国务院特殊津贴的小伙伴算税:
		Income[] incomes = new Income[] { new Income(3000), new Salary(7500), new StateCouncilSpecialAllowance(15000) };
		double total = 0;
		for (Income income : incomes) {
			total = total + income.getTax();
		}
		System.out.println(total);
	}

}
