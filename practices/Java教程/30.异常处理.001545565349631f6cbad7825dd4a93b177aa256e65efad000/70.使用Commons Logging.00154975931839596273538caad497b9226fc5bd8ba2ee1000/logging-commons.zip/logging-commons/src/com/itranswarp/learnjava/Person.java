package com.itranswarp.learnjava;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Person {

	protected final Log log = LogFactory.getLog(getClass());

	String name;

	public Person(String name) {
		this.name = name;
		log.info("new Person created.");
	}

	public void hello() {
		log.info("invoke hello()");
	}

}
