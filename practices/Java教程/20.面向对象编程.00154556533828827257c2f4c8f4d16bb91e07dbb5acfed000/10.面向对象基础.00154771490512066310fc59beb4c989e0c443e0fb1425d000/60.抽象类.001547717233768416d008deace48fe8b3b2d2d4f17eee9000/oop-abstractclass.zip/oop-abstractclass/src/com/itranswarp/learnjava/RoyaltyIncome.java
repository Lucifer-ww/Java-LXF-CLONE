package com.itranswarp.learnjava;

/**
 * 稿费收入税率是20%
 */
public class RoyaltyIncome {

	// TODO

}
