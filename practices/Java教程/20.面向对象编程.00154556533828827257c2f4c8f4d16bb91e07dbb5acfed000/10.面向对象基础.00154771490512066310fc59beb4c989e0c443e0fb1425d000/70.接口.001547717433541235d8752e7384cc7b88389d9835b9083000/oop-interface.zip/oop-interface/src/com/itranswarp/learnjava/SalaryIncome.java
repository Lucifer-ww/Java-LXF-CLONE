package com.itranswarp.learnjava;

public class SalaryIncome {

	// TODO

}
