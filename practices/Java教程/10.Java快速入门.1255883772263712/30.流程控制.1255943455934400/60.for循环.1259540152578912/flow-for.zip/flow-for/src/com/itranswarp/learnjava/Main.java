package com.itranswarp.learnjava;

/**
 * for练习
 */
public class Main {

	public static void main(String[] args) {
		int[] ns = { 1, 4, 9, 16, 25 };
		int sum = 0;
		for (;;) {
		}
		System.out.println(sum);
	}

}
