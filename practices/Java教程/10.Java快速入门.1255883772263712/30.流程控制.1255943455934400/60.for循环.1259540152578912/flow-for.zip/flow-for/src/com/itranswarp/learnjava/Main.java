package com.itranswarp.learnjava;

/**
 * for练习
 */
public class Main {

	public static void main(String[] args) {
		int sum = 0;
		int m = 20;
		int n = 100;
		// FIXME: 使用for计算M+...+N:
		for (;;) {
		}
		System.out.println(sum);
	}

}
